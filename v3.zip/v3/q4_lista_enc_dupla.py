# Problema valendo 2.5 pontos
# Implemente a função "remove_m".
# Complete o código abaixo onde é pedido

from typing import List
from utils import converte_vetor_para_LED, imprimir_LED

class No:
    def __init__(self, chave: int, anterior, proximo):
        self.chave = chave
        self.anterior = anterior
        self.proximo = proximo

class ListaEncDupla:
    def __init__(self):
        self.cabeca = None
        self.cauda = None


# Remove os primeiros m elementos de uma lista encadeada dupla.
# Complexidade esperada: O(m)
def remove_m(lista: ListaEncDupla, m: int):
    if lista.cabeca is None or m <= 0:
        return

    atual = lista.cabeca
    contador = 0

    while atual is not None and contador < m:
        proximo = atual.proximo
        if atual.anterior is not None:
            atual.anterior.proximo = proximo
        else:
            lista.cabeca = proximo
        
        if proximo is not None:
            proximo.anterior = atual.anterior
        else:
            lista.cauda = atual.anterior
        
        contador += 1
        atual = proximo


## TESTES ##

led = converte_vetor_para_LED([10, 20, 30, 20, 10])
m = 2
print("Lista inicial:")
imprimir_LED(led)
print("Após remover", m, "elementos")
remove_m(led, m)
imprimir_LED(led)
print()


led = converte_vetor_para_LED([10, 20, 30])
m = 1
print("Lista inicial:")
imprimir_LED(led)
print("Após remover", m, "elementos")
remove_m(led, m)
imprimir_LED(led)
print()


led = converte_vetor_para_LED([11, 22, 33, 44, 55])
m = 5
print("Lista inicial:")
imprimir_LED(led)
print("Após remover", m, "elementos")
remove_m(led, m)
imprimir_LED(led)
print()

