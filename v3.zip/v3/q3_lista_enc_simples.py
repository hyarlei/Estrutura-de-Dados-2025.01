# Problema valendo:
# 1.5 pontos para implementação iterativa ou
# 2.5 pontos para implementação recursiva
# Implemente a função "somatorio10".

class No:
    def __init__(self, chave: int, proximo):
        self.chave = chave
        self.proximo = proximo

class ListaEncSimples:
    def __init__(self):
        self.cabeca = None


# Implemente a função "soma_positivo".
# A função deve retornar o somatório dos elementos
# da lista que são positivos.
# Complexidade esperada: O(n)
def soma_positivo(lista: ListaEncSimples) -> int:
    atual = lista.cabeca
    soma = 0
    while atual is not None:
        if atual.chave > 0:
            soma += atual.chave
        atual = atual.proximo
    return soma



# Para ganhar mais pontos:
def soma_positivo_rec(atual: No) -> int:
    if atual is None:
        return 0
    if atual.chave > 0:
        return atual.chave + soma_positivo_rec(atual.proximo)
    else:
        return soma_positivo_rec(atual.proximo)


# TESTES #

lista1 = ListaEncSimples()
lista1.cabeca = No(30, No(1, No(10, None)))

lista2 = ListaEncSimples()
lista2.cabeca = No(50, No(-50, No(30, None)))

lista3 = ListaEncSimples()
lista3.cabeca = No(-1, No(0, No(1, None)))

lista4 = ListaEncSimples()
lista4.cabeca = None

print("Esperado: 41")
print("Resultado:", soma_positivo(lista1))
print()

print("Esperado: 80")
print("Resultado:", soma_positivo(lista2))
print()

print("Esperado: 1")
print("Resultado:", soma_positivo(lista3))
print()

print("Esperado: 0")
print("Resultado:", soma_positivo(lista4))
