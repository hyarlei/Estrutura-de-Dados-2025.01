# Arquivo de suporte para as questões
# Ignore esse aquivo

class Pilha:
    def __init__(self):
        self.el = []
def acessar(p):
    return p.el[-1]
def vazia(p) -> bool:
    return len(p.el) == 0
def inserir(p, e):
    p.el.append(e)
def remover(p):
    p.el.pop()
def imprimir(p):
    print("Pilha: base ->", p.el)

class No:
    def __init__(self, chave: int, anterior, proximo):
        self.chave = chave
        self.anterior = anterior
        self.proximo = proximo

class ListaEncDupla:
    def __init__(self):
        self.cabeca = None
        self.cauda = None

def led_inserir_final(lista, chave):
    novo_no = No(chave, None, None)
    if lista.cabeca is None:
        lista.cabeca = novo_no
        lista.cauda = novo_no
    else:
        novo_no.anterior = lista.cauda
        lista.cauda.proximo = novo_no
        lista.cauda = novo_no

def converte_vetor_para_LED(vetor):
    lista = ListaEncDupla()
    for chave in vetor:
        led_inserir_final(lista, chave)
    return lista

def imprimir_LED(lista) -> None:
    atual = lista.cabeca
    print("Lista:", end=" ")
    while atual is not None:
        print(atual.chave, end=" <-> ")
        atual = atual.proximo
    print("None")

    