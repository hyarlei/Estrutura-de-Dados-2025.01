# Problema valendo 2.5 pontos
# Implemente as funcionalidades faltantes da pilha sequencial.
# Complete o código abaixo onde é pedido
from typing import List
from utils import *

# Utilizando apenas o TAD Pilha, inverta o conteúdo da pilha1.
# Os elementos que estavam no topo devem ficar na base e os
# que estavam na base devem ficar no topo.
# Utilize somente pilhas auxiliares p2 e p3.
# Complexidade esperada: O(n)
def inverte_pilha(p1: Pilha):
    p2 = Pilha()
    p3 = Pilha()

    while not vazia(p1):
        e = acessar(p1)
        remover(p1)
        inserir(p2, e)

    while not vazia(p2):
        e = acessar(p2)
        remover(p2)
        inserir(p3, e)

    while not vazia(p3):
        e = acessar(p3)
        remover(p3)
        inserir(p1, e)
def imprimir(p: Pilha) -> None:
    if vazia(p):
        print("Pilha vazia")
    else:
        print("Pilha: base ->", end=" ")
        aux = Pilha()
        while not vazia(p):
            e = acessar(p)
            print(e, end=" ")
            inserir(aux, e)
            remover(p)
        print()
        
        while not vazia(aux):
            e = acessar(aux)
            inserir(p, e)
            remover(aux)


# Funções que você pode usar nessa questão:
# Pilha(), cria uma nova pilha vazia
# acessar(p), retorna o elemento do topo da pilha p
# vazia(p), retorna se a pilha p está vazia
# inserir(p, e), insere o elemento e no topo da pilha p
# remover(p), remove o elemento do topo da pilha p


### TESTES ###

pilha = Pilha()
inserir(pilha, 11)
inserir(pilha, 22)
inserir(pilha, 33)
inserir(pilha, 44)
print("Pilha inicial:")
imprimir(pilha)

print("Pilha final:")
inverte_pilha(pilha)
imprimir(pilha)


